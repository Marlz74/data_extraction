import pandas as pd
from datetime import datetime

# Load the training data from a CSV file
data = pd.read_csv('features_merged.csv')

# Ensure 'Creation Date' and 'Expiration Date' columns are datetime types
data['Creation Date'] = pd.to_datetime(data['Creation Date'], errors='coerce')
data['Expiration Date'] = pd.to_datetime(data['Expiration Date'], errors='coerce')

# Get the current date for calculating the days
current_date = datetime.now()

# Create new columns: Days Since Creation and Days Until Expiration
data['Days Since Creation'] = (current_date - data['Creation Date']).dt.days
data['Days Until Expiration'] = (data['Expiration Date'] - current_date).dt.days

# Drop any rows where the date calculations resulted in NaT (missing data)
data.dropna(subset=['Days Since Creation', 'Days Until Expiration'], inplace=True)

# Keep only the important columns: 'label', 'Domain Name', 'Name Servers', 
# 'Days Since Creation', 'Days Until Expiration', and any other relevant columns.
important_columns = ['label', 'Domain Name', 'Name Servers', 
                     'Days Since Creation', 'Days Until Expiration']
data = data[important_columns]

# Save the updated data to a new CSV file
data.to_csv('train_updated_merged.csv', index=False)

print("Training CSV file updated and saved as 'train_updated_merged.csv'.")
