import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report, f1_score
import joblib

# Step 1: Load and preprocess data
def load_and_preprocess_data(file_path):
    data = pd.read_csv(file_path)
    data.fillna("Missing", inplace=True)  # Handle missing values
    
    # Encode "Name Servers" column using OneHotEncoder
    encoder = OneHotEncoder(handle_unknown='ignore', sparse_output=False)  # Use sparse_output=False
    encoder.fit(data[["Name Servers"]])
    name_servers_encoded = encoder.transform(data[["Name Servers"]])
    encoded_df = pd.DataFrame(name_servers_encoded, columns=encoder.get_feature_names_out(["Name Servers"]))
    data = pd.concat([data, encoded_df], axis=1).drop(columns=["Name Servers"])
    
    # Add derived features for the model
    data["Creation Year"] = pd.to_datetime(data["Creation Date"], errors='coerce').dt.year
    data["Expiration Year"] = pd.to_datetime(data["Expiration Date"], errors='coerce').dt.year
    data["Domain Age"] = data["Expiration Year"] - data["Creation Year"]
    data["Domain Age"] = data["Domain Age"].fillna(0)  # Replace NaNs with 0
    data = data.drop(columns=["Creation Date", "Expiration Date"])  # Drop original date columns

    # Label generation (e.g., heuristic)
    data["Is Fake"] = (data["Domain Age"] < 1).astype(int)

    # Define features (X) and target (y)
    X = data.drop(columns=["Domain Name", "Is Fake"])  # Drop non-numeric columns
    y = data["Is Fake"]  # Target variable

    # Impute missing values in features
    imputer = SimpleImputer(strategy='mean')
    X = imputer.fit_transform(X)

    return train_test_split(X, y, test_size=0.2, random_state=42), encoder

# Step 2: Train models with class weights if needed
def train_models(X_train, y_train):
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
    rf_model.fit(X_train, y_train)

    svr_model = SVC(probability=True, class_weight='balanced')  # Use probability=True for ensemble voting
    svr_model.fit(X_train, y_train)

    knn_model = KNeighborsClassifier(n_neighbors=5)
    knn_model.fit(X_train, y_train)

    return rf_model, svr_model, knn_model

# Step 3: Create and train ensemble
def train_ensemble(rf_model, svr_model, knn_model, X_train, y_train):
    ensemble_model = VotingClassifier(
        estimators=[
            ('random_forest', rf_model),
            ('svc', svr_model),
            ('knn', knn_model)
        ],
        voting='soft'  # Use 'soft' for probability-based voting
    )
    ensemble_model.fit(X_train, y_train)
    return ensemble_model

# Step 4: Evaluate models with more metrics
def evaluate_models(models, ensemble_model, X_test, y_test):
    for name, model in models.items():
        predictions = model.predict(X_test)
        print(f"{name} Accuracy:", accuracy_score(y_test, predictions))
        print(f"{name} F1 Score:", f1_score(y_test, predictions, average='binary'))
        print(f"{name} Classification Report:\n", classification_report(y_test, predictions))
    
    ensemble_predictions = ensemble_model.predict(X_test)
    print("Ensemble Model Accuracy:", accuracy_score(y_test, ensemble_predictions))
    print("Ensemble Model F1 Score:", f1_score(y_test, ensemble_predictions, average='binary'))
    print("Ensemble Model Classification Report:\n", classification_report(y_test, ensemble_predictions))

# Step 5: Save and load model
def save_model(model, file_name):
    joblib.dump(model, file_name)

def load_model(file_name):
    return joblib.load(file_name)

# Step 6: Predict new data
def predict_new_data(model, new_data, encoder):
    new_data.fillna("Missing", inplace=True)
    
    # Transform "Name Servers" column with encoder (sparse format)
    new_data_encoded = encoder.transform(new_data[["Name Servers"]])
    encoded_df = pd.DataFrame(new_data_encoded.toarray(), columns=encoder.get_feature_names_out(["Name Servers"]))
    new_data = pd.concat([new_data, encoded_df], axis=1).drop(columns=["Name Servers"])
    
    # Process other transformations
    new_data["Creation Year"] = pd.to_datetime(new_data["Creation Date"], errors='coerce').dt.year
    new_data["Expiration Year"] = pd.to_datetime(new_data["Expiration Date"], errors='coerce').dt.year
    new_data["Domain Age"] = new_data["Expiration Year"] - new_data["Creation Year"]
    new_data["Domain Age"] = new_data["Domain Age"].fillna(0)  # Replace NaNs with 0
    new_data = new_data.drop(columns=["Creation Date", "Expiration Date"])
    
    # Impute missing values in new data
    imputer = SimpleImputer(strategy='mean')
    new_data = imputer.fit_transform(new_data)
    
    return model.predict(new_data)

# Main function to orchestrate the steps
if __name__ == "__main__":
    # File path to the dataset
    file_path = "../merged/test_features.csv"  # Replace with the actual file path

    # Load and preprocess data
    (X_train, X_test, y_train, y_test), encoder = load_and_preprocess_data(file_path)

    # Train models
    rf_model, svr_model, knn_model = train_models(X_train, y_train)

    # Train ensemble model
    ensemble_model = train_ensemble(rf_model, svr_model, knn_model, X_train, y_train)

    # Evaluate models
    models = {
        "Random Forest": rf_model,
        "Support Vector Classifier": svr_model,
        "K-Neighbors Classifier": knn_model
    }
    evaluate_models(models, ensemble_model, X_test, y_test)

    # Save the ensemble model
    save_model(ensemble_model, "ensemble_model_v1.pkl")

    # Predict new data
    new_data = pd.DataFrame({
        "Domain Length": [12],
        "Vowel Count": [5],
        "Consonant Count": [6],
        "Numeric Count": [0],
        "Other Character Count": [1],
        "Entropy": [3.5],
        "Name Servers": ["DNS1.EXAMPLE.COM, DNS2.EXAMPLE.COM"],
        "Creation Date": ["2021-01-01"],
        "Expiration Date": ["2026-01-01"]
    })
    loaded_model = load_model("ensemble_model_v1.pkl")
    predictions = predict_new_data(loaded_model, new_data, encoder)
    print("Predictions for New Data:", predictions)
