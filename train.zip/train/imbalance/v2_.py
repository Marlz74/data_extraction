

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, VotingRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.impute import SimpleImputer
import joblib

# Step 1: Load and preprocess data
def load_and_preprocess_data(file_path):
    data = pd.read_csv(file_path)
    data.fillna("Missing", inplace=True)  # Handle missing values
    
    # Encode categorical features
    encoder = LabelEncoder()
    data["Domain Name"] = encoder.fit_transform(data["Domain Name"])
    data["Name Servers"] = encoder.fit_transform(data["Name Servers"])
    
    # Add derived features
    data["Creation Year"] = pd.to_datetime(data["Creation Date"], errors='coerce').dt.year
    data["Expiration Year"] = pd.to_datetime(data["Expiration Date"], errors='coerce').dt.year
    data["Domain Age"] = data["Expiration Year"] - data["Creation Year"]
    data["Domain Age"] = data["Domain Age"].fillna(0)  # Replace NaNs with 0
    
    # Drop unnecessary columns
    data = data.drop(columns=["Creation Date", "Expiration Date"])
    
    # Define features (X) and target (y)
    X = data.drop(columns=["Domain Name"])  # Choose appropriate target if needed
    y = data["Domain Name"]

    # Impute missing values in features
    imputer = SimpleImputer(strategy='mean')
    X = imputer.fit_transform(X)

    return train_test_split(X, y, test_size=0.2, random_state=42), encoder

# Step 2: Train models
def train_models(X_train, y_train):
    rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
    rf_model.fit(X_train, y_train)
    
    svr_model = SVR(kernel='linear')
    svr_model.fit(X_train, y_train)
    
    knn_model = KNeighborsRegressor(n_neighbors=5)
    knn_model.fit(X_train, y_train)
    
    return rf_model, svr_model, knn_model

# Step 3: Create and train ensemble
def train_ensemble(rf_model, svr_model, knn_model, X_train, y_train):
    ensemble_model = VotingRegressor(
        estimators=[
            ('random_forest', rf_model),
            ('svr', svr_model),
            ('knn', knn_model)
        ]
    )
    ensemble_model.fit(X_train, y_train)
    return ensemble_model

# Step 4: Evaluate models
def evaluate_models(models, ensemble_model, X_test, y_test):
    for name, model in models.items():
        predictions = model.predict(X_test)
        print(f"{name} RMSE:", np.sqrt(mean_squared_error(y_test, predictions)))
        print(f"{name} R^2 Score:", r2_score(y_test, predictions))
    
    ensemble_predictions = ensemble_model.predict(X_test)
    print("Ensemble Model RMSE:", np.sqrt(mean_squared_error(y_test, ensemble_predictions)))
    print("Ensemble Model R^2 Score:", r2_score(y_test, ensemble_predictions))

# Step 5: Save and load model
def save_model(model, file_name):
    joblib.dump(model, file_name)

def load_model(file_name):
    return joblib.load(file_name)

# Step 6: Predict new data
def predict_new_data(model, new_data, encoder):
    new_data.fillna("Missing", inplace=True)
    new_data["Name Servers"] = encoder.transform(new_data["Name Servers"])
    new_data["Creation Year"] = pd.to_datetime(new_data["Creation Date"], errors='coerce').dt.year
    new_data["Expiration Year"] = pd.to_datetime(new_data["Expiration Date"], errors='coerce').dt.year
    new_data["Domain Age"] = new_data["Expiration Year"] - new_data["Creation Year"]
    new_data["Domain Age"] = new_data["Domain Age"].fillna(0)  # Replace NaNs with 0
    new_data = new_data.drop(columns=["Creation Date", "Expiration Date"])
    
    # Impute missing values in new data
    imputer = SimpleImputer(strategy='mean')
    new_data = imputer.fit_transform(new_data)
    
    return model.predict(new_data)

# Main function to orchestrate the steps
if __name__ == "__main__":
    # File path to the dataset
    file_path = "../merged/test_features.csv"  # Replace with the actual file path
    
    # Load and preprocess data
    (X_train, X_test, y_train, y_test), encoder = load_and_preprocess_data(file_path)
    
    # Train models
    rf_model, svr_model, knn_model = train_models(X_train, y_train)
    
    # Train ensemble model
    ensemble_model = train_ensemble(rf_model, svr_model, knn_model, X_train, y_train)
    
    # Evaluate models
    models = {
        "Random Forest": rf_model,
        "Support Vector Regressor": svr_model,
        "K-Neighbors Regressor": knn_model
    }
    evaluate_models(models, ensemble_model, X_test, y_test)
    
    # Save the ensemble model
    save_model(ensemble_model, "ensemble_model.pkl")
    
    # Predict new data
    new_data = pd.DataFrame({
        "Domain Length": [12],
        "Vowel Count": [5],
        "Consonant Count": [6],
        "Numeric Count": [0],
        "Other Character Count": [1],
        "Entropy": [3.5],
        "Name Servers": ["DNS1.EXAMPLE.COM, DNS2.EXAMPLE.COM"],
        "Creation Date": ["2021-01-01"],
        "Expiration Date": ["2026-01-01"]
    })
    loaded_model = load_model("ensemble_model.pkl")
    predictions = predict_new_data(loaded_model, new_data, encoder)
    print("Predictions for New Data:", predictions)


