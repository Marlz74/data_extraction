import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
import joblib

# Step 1: Load and preprocess data
def load_and_preprocess_data(file_path):
    data = pd.read_csv(file_path)

    # Handle missing values for categorical columns
    data.fillna("Missing", inplace=True)

    # Select only the relevant features for training
    relevant_features = ["Domain Name", "Name Servers", "Days Since Creation", "Days Until Expiration"]
    data = data[relevant_features + ["label"]]

    # Define columns for one-hot encoding and numeric processing
    categorical_features = ["Domain Name", "Name Servers"]
    numeric_features = ["Days Since Creation", "Days Until Expiration"]

    # Create a column transformer for preprocessing
    preprocessor = ColumnTransformer(
        transformers=[
            ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features),
            ('num', StandardScaler(), numeric_features)
        ]
    )

    # Separate features (X) and target (y)
    X = data.drop(columns=["label"])
    y = data["label"]

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Fit the preprocessor and transform the training data
    X_train = preprocessor.fit_transform(X_train)
    X_test = preprocessor.transform(X_test)

    return X_train, X_test, y_train, y_test, preprocessor

# Step 2: Train models
def train_models(X_train, y_train):
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train, y_train)

    svc_model = SVC(kernel='linear', probability=True)
    svc_model.fit(X_train, y_train)

    knn_model = KNeighborsClassifier(n_neighbors=5)
    knn_model.fit(X_train, y_train)

    return rf_model, svc_model, knn_model

# Step 3: Train the ensemble model
def train_ensemble(rf_model, svc_model, knn_model, X_train, y_train):
    base_learners = [
        ('rf', rf_model),
        ('svc', svc_model),
        ('knn', knn_model)
    ]
    ensemble_model = StackingClassifier(
        estimators=base_learners,
        final_estimator=RandomForestClassifier(n_estimators=50, random_state=42)
    )
    ensemble_model.fit(X_train, y_train)
    return ensemble_model

# Step 4: Evaluate models
def evaluate_models(models, ensemble_model, X_test, y_test):
    for name, model in models.items():
        accuracy = model.score(X_test, y_test)
        print(f"{name} accuracy: {accuracy:.2f}")
    
    ensemble_accuracy = ensemble_model.score(X_test, y_test)
    print(f"Ensemble model accuracy: {ensemble_accuracy:.2f}")

# Step 5: Save the model using joblib
def save_model(model, filename):
    joblib.dump(model, filename)
    print(f"Model saved as {filename}")

# Step 6: Load a model using joblib
def load_model(filename):
    return joblib.load(filename)

# Main function to orchestrate the steps
if __name__ == "__main__":
    # File path to the dataset
    file_path = "./train_updated.csv"  # Replace with the actual file path

    # Load and preprocess data
    X_train, X_test, y_train, y_test, preprocessor = load_and_preprocess_data(file_path)

    # Train models
    rf_model, svc_model, knn_model = train_models(X_train, y_train)

    # Train ensemble model
    ensemble_model = train_ensemble(rf_model, svc_model, knn_model, X_train, y_train)

    # Evaluate models
    models = {
        "Random Forest": rf_model,
        "Support Vector Classifier": svc_model,
        "K-Neighbors Classifier": knn_model
    }
    evaluate_models(models, ensemble_model, X_test, y_test)

    # Save the ensemble model and preprocessor
    save_model(ensemble_model, "ensemble_model.pkl")
    save_model(preprocessor, "preprocessor.pkl")

    # Predict new data
    new_data = pd.DataFrame({
        "Domain Name": ["example.com"],
        "Name Servers": ["dns1.example.com, dns2.example.com"],
        "Days Since Creation": [1000],
        "Days Until Expiration": [200]
    })

    # Load the saved model and preprocessor
    loaded_model = load_model("ensemble_model.pkl")
    loaded_preprocessor = load_model("preprocessor.pkl")

    # Transform new data using the preprocessor before prediction
    new_data_transformed = loaded_preprocessor.transform(new_data)
    predictions = loaded_model.predict(new_data_transformed)

    print("Predictions for new data:", predictions)
