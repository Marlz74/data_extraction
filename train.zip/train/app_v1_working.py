import pandas as pd
import numpy as np
import time
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from scipy.sparse import csr_matrix, hstack

# Title for the app
st.title("Machine Learning Model Evaluation App")

# File uploader for CSV dataset
uploaded_file = st.file_uploader("Upload a CSV file", type="csv")

# Function to process data and train models
def process_data(file_path):
    try:
        data = pd.read_csv(file_path)
        st.success("Dataset loaded successfully.")
    except FileNotFoundError:
        st.error(f"The file {file_path} does not exist.")
        return None
    except pd.errors.EmptyDataError:
        st.error("The file is empty.")
        return None
    except Exception as e:
        st.error(f"An error occurred while loading the file: {e}")
        return None

    # Check for missing values and handle them
    numeric_columns = data.select_dtypes(include=[np.number]).columns
    categorical_columns = data.select_dtypes(exclude=[np.number]).columns

    # Fill missing values for numeric and categorical columns
    data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].mean())
    data[categorical_columns] = data[categorical_columns].fillna(data[categorical_columns].mode().iloc[0])

    # Check for duplicate rows
    if data.duplicated().any():
        st.warning("Dataset contains duplicate rows. Removing duplicates...")
        data = data.drop_duplicates()

    # Separate features and labels
    try:
        X = data.drop("label", axis=1)
        y = data["label"]
    except KeyError:
        st.error("The dataset must contain a 'label' column for classification.")
        return None

    # Encode categorical features
    categorical_features = X.select_dtypes(include=["object"]).columns
    if len(categorical_features) > 0:
        st.write(f"Encoding {len(categorical_features)} categorical features...")
        encoder = OneHotEncoder(sparse_output=True, handle_unknown='ignore')
        sparse_encoded_data = encoder.fit_transform(X[categorical_features])
        X = X.drop(categorical_features, axis=1)
        X = hstack([csr_matrix(X), sparse_encoded_data])

    # Scale the data
    scaler = StandardScaler(with_mean=False)
    X = scaler.fit_transform(X)

    return X, y

# Function to train models and evaluate them
def train_and_evaluate(X, y):
    models = {
        "Random Forest": RandomForestClassifier(random_state=42, n_jobs=-1),
        "Logistic Regression": LogisticRegression(solver='saga', max_iter=500, random_state=42, n_jobs=-1),
        "Naive Bayes (Gaussian)": GaussianNB(),
        "K-Nearest Neighbors": KNeighborsClassifier(n_jobs=-1),
        "Support Vector Machine": SVC(kernel="linear", random_state=42, probability=True),
    }

    # Split the dataset
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    # Start timer for model training and evaluation
    start_time = time.time()

    # Train and evaluate each model
    results = {}
    for model_name, model in models.items():
        try:
            if isinstance(model, GaussianNB):
                X_train_dense = X_train.toarray()
                X_test_dense = X_test.toarray()
            else:
                X_train_dense = X_train
                X_test_dense = X_test

            model.fit(X_train_dense, y_train)
            y_pred = model.predict(X_test_dense)

            accuracy = accuracy_score(y_test, y_pred)
            st.write(f"### Model: {model_name}")
            st.write(f"**Accuracy**: {accuracy:.4f}")
            st.write("**Confusion Matrix**:")
            st.write(confusion_matrix(y_test, y_pred))
            st.write("**Classification Report**:")
            st.text(classification_report(y_test, y_pred))

            # Store results
            results[model_name] = {
                "accuracy": accuracy,
                "confusion_matrix": confusion_matrix(y_test, y_pred),
                "classification_report": classification_report(y_test, y_pred, output_dict=True)
            }
        except Exception as e:
            st.error(f"An error occurred with {model_name}: {e}")
            continue

    # End timer
    end_time = time.time()
    time_taken = end_time - start_time
    st.write(f"### Total time taken for training and evaluation: {time_taken:.2f} seconds")

    return results

# Display the app UI logic
if uploaded_file is not None:
    X, y = process_data(uploaded_file)
    if X is not None and y is not None:
        if st.button("Run Model Training and Evaluation"):
            results = train_and_evaluate(X, y)
            if results:
                best_model = max(results, key=lambda x: results[x]["accuracy"])
                st.write(f"### Best Model: {best_model} with Accuracy: {results[best_model]['accuracy']:.4f}")
